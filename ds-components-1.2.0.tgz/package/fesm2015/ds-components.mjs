import * as i0 from '@angular/core';
import { EventEmitter, Component, Input, Output, forwardRef, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2$1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i2$2 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i3 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i2$3 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import * as i4 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i4$1 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class DsButtonComponent {
    constructor() {
        this.variant = 'primary';
        this.disabled = false;
        this.type = 'button';
        this.clicked = new EventEmitter();
    }
    get color() {
        switch (this.variant) {
            case 'danger':
                return 'warn';
            case 'secondary':
                return 'accent';
            default:
                return 'primary';
        }
    }
    onClick(event) {
        if (!this.disabled) {
            this.clicked.emit(event);
        }
    }
}
DsButtonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsButtonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsButtonComponent, selector: "ds-button", inputs: { variant: "variant", disabled: "disabled", type: "type" }, outputs: { clicked: "clicked" }, ngImport: i0, template: "<button\n  mat-raised-button\n  class=\"ds-button\"\n  [class.ds-button--secondary]=\"variant === 'secondary'\"\n  [class.ds-button--danger]=\"variant === 'danger'\"\n  [color]=\"color\"\n  [disabled]=\"disabled\"\n  [type]=\"type\"\n  (click)=\"onClick($event)\"\n>\n  <ng-content></ng-content>\n</button>\n", styles: [":host{display:inline-block}.ds-button{border-radius:2px;min-width:96px;text-transform:uppercase;letter-spacing:.08em}::ng-deep .ds-button .mat-button-wrapper{display:inline-flex;align-items:center;gap:6px;font-weight:600;font-size:13px;line-height:34px}::ng-deep .ds-button .mat-button-focus-overlay{background-color:#0000001f}::ng-deep .ds-button .mat-button-ripple{border-radius:2px}\n"], dependencies: [{ kind: "component", type: i2.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ds-button', template: "<button\n  mat-raised-button\n  class=\"ds-button\"\n  [class.ds-button--secondary]=\"variant === 'secondary'\"\n  [class.ds-button--danger]=\"variant === 'danger'\"\n  [color]=\"color\"\n  [disabled]=\"disabled\"\n  [type]=\"type\"\n  (click)=\"onClick($event)\"\n>\n  <ng-content></ng-content>\n</button>\n", styles: [":host{display:inline-block}.ds-button{border-radius:2px;min-width:96px;text-transform:uppercase;letter-spacing:.08em}::ng-deep .ds-button .mat-button-wrapper{display:inline-flex;align-items:center;gap:6px;font-weight:600;font-size:13px;line-height:34px}::ng-deep .ds-button .mat-button-focus-overlay{background-color:#0000001f}::ng-deep .ds-button .mat-button-ripple{border-radius:2px}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], disabled: [{
                type: Input
            }], type: [{
                type: Input
            }], clicked: [{
                type: Output
            }] } });

class DsCardComponent {
    constructor() {
        this.title = '';
        this.subtitle = '';
        this.elevated = true;
    }
}
DsCardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsCardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsCardComponent, selector: "ds-card", inputs: { title: "title", subtitle: "subtitle", elevated: "elevated" }, ngImport: i0, template: "<mat-card class=\"ds-card\" [class.ds-card--flat]=\"!elevated\">\n  <mat-card-header *ngIf=\"title || subtitle\" class=\"ds-card__header\">\n    <mat-card-title *ngIf=\"title\">{{ title }}</mat-card-title>\n    <mat-card-subtitle *ngIf=\"subtitle\">{{ subtitle }}</mat-card-subtitle>\n  </mat-card-header>\n  <mat-card-content class=\"ds-card__content\">\n    <ng-content></ng-content>\n  </mat-card-content>\n  <mat-card-actions class=\"ds-card__actions\" align=\"end\">\n    <ng-content select=\"[ds-card-actions]\"></ng-content>\n  </mat-card-actions>\n</mat-card>\n", styles: [":host{display:block}.ds-card{border-radius:4px;border-top:3px solid #1f4e79;padding:0}.ds-card--flat{box-shadow:none;border:1px solid #d9dde3;border-top:3px solid #1f4e79}::ng-deep .ds-card .mat-card-header-text{margin:0;padding:16px 20px 0}::ng-deep .ds-card .mat-card-header-text .mat-card-title{font-size:16px;font-weight:600;color:#1f2933;margin-bottom:4px}::ng-deep .ds-card .mat-card-content{padding:16px 20px;margin-bottom:0}::ng-deep .ds-card .mat-card-actions{padding:8px 12px;margin:0;border-top:1px solid #eef1f4}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2$1.MatCard, selector: "mat-card", exportAs: ["matCard"] }, { kind: "component", type: i2$1.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i2$1.MatCardContent, selector: "mat-card-content, [mat-card-content], [matCardContent]" }, { kind: "directive", type: i2$1.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "directive", type: i2$1.MatCardSubtitle, selector: "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]" }, { kind: "directive", type: i2$1.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ds-card', template: "<mat-card class=\"ds-card\" [class.ds-card--flat]=\"!elevated\">\n  <mat-card-header *ngIf=\"title || subtitle\" class=\"ds-card__header\">\n    <mat-card-title *ngIf=\"title\">{{ title }}</mat-card-title>\n    <mat-card-subtitle *ngIf=\"subtitle\">{{ subtitle }}</mat-card-subtitle>\n  </mat-card-header>\n  <mat-card-content class=\"ds-card__content\">\n    <ng-content></ng-content>\n  </mat-card-content>\n  <mat-card-actions class=\"ds-card__actions\" align=\"end\">\n    <ng-content select=\"[ds-card-actions]\"></ng-content>\n  </mat-card-actions>\n</mat-card>\n", styles: [":host{display:block}.ds-card{border-radius:4px;border-top:3px solid #1f4e79;padding:0}.ds-card--flat{box-shadow:none;border:1px solid #d9dde3;border-top:3px solid #1f4e79}::ng-deep .ds-card .mat-card-header-text{margin:0;padding:16px 20px 0}::ng-deep .ds-card .mat-card-header-text .mat-card-title{font-size:16px;font-weight:600;color:#1f2933;margin-bottom:4px}::ng-deep .ds-card .mat-card-content{padding:16px 20px;margin-bottom:0}::ng-deep .ds-card .mat-card-actions{padding:8px 12px;margin:0;border-top:1px solid #eef1f4}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], elevated: [{
                type: Input
            }] } });

class DsFormFieldComponent {
    constructor() {
        this.label = '';
        this.placeholder = '';
        this.hint = '';
        this.error = '';
        this.type = 'text';
        this.required = false;
        this.value = '';
        this.disabled = false;
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    writeValue(value) {
        this.value = value !== null && value !== void 0 ? value : '';
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onInput(event) {
        this.value = event.target.value;
        this.onChange(this.value);
    }
    onBlur() {
        this.onTouched();
    }
}
DsFormFieldComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsFormFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsFormFieldComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsFormFieldComponent, selector: "ds-form-field", inputs: { label: "label", placeholder: "placeholder", hint: "hint", error: "error", type: "type", required: "required" }, providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => DsFormFieldComponent),
            multi: true,
        },
    ], ngImport: i0, template: "<mat-form-field class=\"ds-form-field\" appearance=\"outline\" floatLabel=\"always\">\n  <mat-label *ngIf=\"label\">{{ label }}</mat-label>\n  <input\n    matInput\n    [type]=\"type\"\n    [placeholder]=\"placeholder\"\n    [required]=\"required\"\n    [disabled]=\"disabled\"\n    [value]=\"value\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  />\n  <mat-hint *ngIf=\"hint\">{{ hint }}</mat-hint>\n  <mat-error *ngIf=\"error\">{{ error }}</mat-error>\n</mat-form-field>\n", styles: [":host{display:block}.ds-form-field{width:100%}::ng-deep .ds-form-field .mat-form-field-wrapper{padding-bottom:1.1em;margin:0}::ng-deep .ds-form-field .mat-form-field-infix{padding:.6em 0 .8em;border-top-width:.6em;font-size:14px}::ng-deep .ds-form-field .mat-form-field-flex{background-color:#fbfcfd;border-radius:2px}::ng-deep .ds-form-field .mat-form-field-outline{color:#b8c2cc}::ng-deep .ds-form-field .mat-form-field-label{font-weight:600;letter-spacing:.02em;color:#52606d}::ng-deep .ds-form-field .mat-form-field-subscript-wrapper{font-size:11px;margin-top:.4em}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$2.MatError, selector: "mat-error", inputs: ["id"] }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["color", "appearance", "hideRequiredMarker", "hintLabel", "floatLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsFormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ds-form-field', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DsFormFieldComponent),
                            multi: true,
                        },
                    ], template: "<mat-form-field class=\"ds-form-field\" appearance=\"outline\" floatLabel=\"always\">\n  <mat-label *ngIf=\"label\">{{ label }}</mat-label>\n  <input\n    matInput\n    [type]=\"type\"\n    [placeholder]=\"placeholder\"\n    [required]=\"required\"\n    [disabled]=\"disabled\"\n    [value]=\"value\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  />\n  <mat-hint *ngIf=\"hint\">{{ hint }}</mat-hint>\n  <mat-error *ngIf=\"error\">{{ error }}</mat-error>\n</mat-form-field>\n", styles: [":host{display:block}.ds-form-field{width:100%}::ng-deep .ds-form-field .mat-form-field-wrapper{padding-bottom:1.1em;margin:0}::ng-deep .ds-form-field .mat-form-field-infix{padding:.6em 0 .8em;border-top-width:.6em;font-size:14px}::ng-deep .ds-form-field .mat-form-field-flex{background-color:#fbfcfd;border-radius:2px}::ng-deep .ds-form-field .mat-form-field-outline{color:#b8c2cc}::ng-deep .ds-form-field .mat-form-field-label{font-weight:600;letter-spacing:.02em;color:#52606d}::ng-deep .ds-form-field .mat-form-field-subscript-wrapper{font-size:11px;margin-top:.4em}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], type: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

class DsDataTableComponent {
    constructor() {
        this.columns = [];
        this.rows = [];
        this.striped = true;
    }
    get displayedColumns() {
        return this.columns.map((c) => c.key);
    }
}
DsDataTableComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsDataTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsDataTableComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsDataTableComponent, selector: "ds-data-table", inputs: { columns: "columns", rows: "rows", striped: "striped" }, ngImport: i0, template: "<div class=\"ds-data-table\" [class.ds-data-table--striped]=\"striped\">\n  <table mat-table [dataSource]=\"rows\">\n    <ng-container *ngFor=\"let col of columns\" [matColumnDef]=\"col.key\">\n      <th mat-header-cell *matHeaderCellDef [style.width]=\"col.width || null\">{{ col.header }}</th>\n      <td mat-cell *matCellDef=\"let row\">{{ row[col.key] }}</td>\n    </ng-container>\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n    <tr mat-row *matRowDef=\"let row; columns: displayedColumns\"></tr>\n  </table>\n  <div *ngIf=\"!rows.length\" class=\"ds-data-table__empty\">No records to display</div>\n</div>\n", styles: [":host{display:block}.ds-data-table{border:1px solid #d9dde3;border-radius:4px;overflow:auto}.ds-data-table table{width:100%}.ds-data-table__empty{padding:24px;text-align:center;color:#7b8794;font-size:13px}::ng-deep .ds-data-table .mat-header-cell{background-color:#f0f3f6;color:#1f2933;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;border-bottom:2px solid #1f4e79}::ng-deep .ds-data-table .mat-cell{font-size:13px;color:#3e4c59;border-bottom-color:#eef1f4}::ng-deep .ds-data-table--striped .mat-row:nth-child(even){background-color:#fafbfc}::ng-deep .ds-data-table .mat-row:hover{background-color:#e8f0f8}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2$3.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i2$3.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i2$3.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i2$3.MatColumnDef, selector: "[matColumnDef]", inputs: ["sticky", "matColumnDef"] }, { kind: "directive", type: i2$3.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i2$3.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i2$3.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i2$3.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i2$3.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i2$3.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsDataTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ds-data-table', template: "<div class=\"ds-data-table\" [class.ds-data-table--striped]=\"striped\">\n  <table mat-table [dataSource]=\"rows\">\n    <ng-container *ngFor=\"let col of columns\" [matColumnDef]=\"col.key\">\n      <th mat-header-cell *matHeaderCellDef [style.width]=\"col.width || null\">{{ col.header }}</th>\n      <td mat-cell *matCellDef=\"let row\">{{ row[col.key] }}</td>\n    </ng-container>\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n    <tr mat-row *matRowDef=\"let row; columns: displayedColumns\"></tr>\n  </table>\n  <div *ngIf=\"!rows.length\" class=\"ds-data-table__empty\">No records to display</div>\n</div>\n", styles: [":host{display:block}.ds-data-table{border:1px solid #d9dde3;border-radius:4px;overflow:auto}.ds-data-table table{width:100%}.ds-data-table__empty{padding:24px;text-align:center;color:#7b8794;font-size:13px}::ng-deep .ds-data-table .mat-header-cell{background-color:#f0f3f6;color:#1f2933;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;border-bottom:2px solid #1f4e79}::ng-deep .ds-data-table .mat-cell{font-size:13px;color:#3e4c59;border-bottom-color:#eef1f4}::ng-deep .ds-data-table--striped .mat-row:nth-child(even){background-color:#fafbfc}::ng-deep .ds-data-table .mat-row:hover{background-color:#e8f0f8}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], rows: [{
                type: Input
            }], striped: [{
                type: Input
            }] } });

class DsAlertComponent {
    constructor() {
        this.severity = 'info';
        this.title = '';
        this.dismissible = false;
        this.dismissed = new EventEmitter();
        this.visible = true;
    }
    get icon() {
        switch (this.severity) {
            case 'success':
                return 'check_circle';
            case 'warning':
                return 'warning';
            case 'error':
                return 'error';
            default:
                return 'info';
        }
    }
    dismiss() {
        this.visible = false;
        this.dismissed.emit();
    }
}
DsAlertComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsAlertComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsAlertComponent, selector: "ds-alert", inputs: { severity: "severity", title: "title", dismissible: "dismissible" }, outputs: { dismissed: "dismissed" }, ngImport: i0, template: "<mat-card *ngIf=\"visible\" class=\"ds-alert\" [ngClass]=\"'ds-alert--' + severity\" role=\"alert\">\n  <mat-icon class=\"ds-alert__icon\">{{ icon }}</mat-icon>\n  <div class=\"ds-alert__body\">\n    <div *ngIf=\"title\" class=\"ds-alert__title\">{{ title }}</div>\n    <div class=\"ds-alert__message\"><ng-content></ng-content></div>\n  </div>\n  <button *ngIf=\"dismissible\" mat-icon-button class=\"ds-alert__close\" aria-label=\"Dismiss\" (click)=\"dismiss()\">\n    <mat-icon>close</mat-icon>\n  </button>\n</mat-card>\n", styles: [":host{display:block}.ds-alert{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-left:4px solid;border-radius:2px;box-shadow:none}.ds-alert__body{flex:1;font-size:13px}.ds-alert__title{font-weight:600;margin-bottom:2px}.ds-alert--info{border-color:#1f4e79;background:#eaf2fa}.ds-alert--success{border-color:#2e7d32;background:#ecf6ed}.ds-alert--warning{border-color:#ed6c02;background:#fff4e5}.ds-alert--error{border-color:#c62828;background:#fdecea}::ng-deep .ds-alert .mat-icon{width:20px;height:20px;font-size:20px;line-height:20px}::ng-deep .ds-alert .ds-alert__close .mat-button-wrapper{display:flex;align-items:center;justify-content:center}::ng-deep .ds-alert .ds-alert__close.mat-icon-button{width:28px;height:28px;line-height:28px}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i2$1.MatCard, selector: "mat-card", exportAs: ["matCard"] }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ds-alert', template: "<mat-card *ngIf=\"visible\" class=\"ds-alert\" [ngClass]=\"'ds-alert--' + severity\" role=\"alert\">\n  <mat-icon class=\"ds-alert__icon\">{{ icon }}</mat-icon>\n  <div class=\"ds-alert__body\">\n    <div *ngIf=\"title\" class=\"ds-alert__title\">{{ title }}</div>\n    <div class=\"ds-alert__message\"><ng-content></ng-content></div>\n  </div>\n  <button *ngIf=\"dismissible\" mat-icon-button class=\"ds-alert__close\" aria-label=\"Dismiss\" (click)=\"dismiss()\">\n    <mat-icon>close</mat-icon>\n  </button>\n</mat-card>\n", styles: [":host{display:block}.ds-alert{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-left:4px solid;border-radius:2px;box-shadow:none}.ds-alert__body{flex:1;font-size:13px}.ds-alert__title{font-weight:600;margin-bottom:2px}.ds-alert--info{border-color:#1f4e79;background:#eaf2fa}.ds-alert--success{border-color:#2e7d32;background:#ecf6ed}.ds-alert--warning{border-color:#ed6c02;background:#fff4e5}.ds-alert--error{border-color:#c62828;background:#fdecea}::ng-deep .ds-alert .mat-icon{width:20px;height:20px;font-size:20px;line-height:20px}::ng-deep .ds-alert .ds-alert__close .mat-button-wrapper{display:flex;align-items:center;justify-content:center}::ng-deep .ds-alert .ds-alert__close.mat-icon-button{width:28px;height:28px;line-height:28px}\n"] }]
        }], propDecorators: { severity: [{
                type: Input
            }], title: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], dismissed: [{
                type: Output
            }] } });

class DsNavHeaderComponent {
    constructor() {
        this.appName = '';
        this.links = [];
        this.navigate = new EventEmitter();
        this.menuToggle = new EventEmitter();
    }
    onNavigate(link, event) {
        event.preventDefault();
        this.navigate.emit(link);
    }
}
DsNavHeaderComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsNavHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsNavHeaderComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsNavHeaderComponent, selector: "ds-nav-header", inputs: { appName: "appName", links: "links" }, outputs: { navigate: "navigate", menuToggle: "menuToggle" }, ngImport: i0, template: "<mat-toolbar color=\"primary\" class=\"ds-nav-header\">\n  <button mat-icon-button class=\"ds-nav-header__menu\" aria-label=\"Toggle menu\" (click)=\"menuToggle.emit()\">\n    <mat-icon>menu</mat-icon>\n  </button>\n  <span class=\"ds-nav-header__brand\">{{ appName }}</span>\n  <nav class=\"ds-nav-header__links\">\n    <a\n      *ngFor=\"let link of links\"\n      mat-button\n      class=\"ds-nav-header__link\"\n      [class.ds-nav-header__link--active]=\"link.active\"\n      [href]=\"link.route\"\n      (click)=\"onNavigate(link, $event)\"\n    >\n      {{ link.label }}\n    </a>\n  </nav>\n  <span class=\"ds-nav-header__spacer\"></span>\n  <ng-content select=\"[ds-nav-actions]\"></ng-content>\n</mat-toolbar>\n", styles: [":host{display:block}.ds-nav-header{height:56px;padding:0 12px;box-shadow:0 2px 4px #0003}.ds-nav-header__brand{font-size:18px;font-weight:700;letter-spacing:.04em;margin:0 24px 0 8px}.ds-nav-header__links{display:flex;gap:4px}.ds-nav-header__link--active{border-bottom:2px solid #fff;border-radius:0}.ds-nav-header__spacer{flex:1 1 auto}::ng-deep .ds-nav-header .mat-toolbar-row,::ng-deep .ds-nav-header.mat-toolbar-single-row{height:56px}::ng-deep .ds-nav-header .ds-nav-header__link .mat-button-wrapper{font-size:13px;font-weight:500;text-transform:uppercase;letter-spacing:.06em}::ng-deep .ds-nav-header .ds-nav-header__menu .mat-button-wrapper{display:flex;align-items:center;justify-content:center}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: i2.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i2.MatAnchor, selector: "a[mat-button], a[mat-raised-button], a[mat-icon-button], a[mat-fab],             a[mat-mini-fab], a[mat-stroked-button], a[mat-flat-button]", inputs: ["disabled", "disableRipple", "color", "tabIndex"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsNavHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ds-nav-header', template: "<mat-toolbar color=\"primary\" class=\"ds-nav-header\">\n  <button mat-icon-button class=\"ds-nav-header__menu\" aria-label=\"Toggle menu\" (click)=\"menuToggle.emit()\">\n    <mat-icon>menu</mat-icon>\n  </button>\n  <span class=\"ds-nav-header__brand\">{{ appName }}</span>\n  <nav class=\"ds-nav-header__links\">\n    <a\n      *ngFor=\"let link of links\"\n      mat-button\n      class=\"ds-nav-header__link\"\n      [class.ds-nav-header__link--active]=\"link.active\"\n      [href]=\"link.route\"\n      (click)=\"onNavigate(link, $event)\"\n    >\n      {{ link.label }}\n    </a>\n  </nav>\n  <span class=\"ds-nav-header__spacer\"></span>\n  <ng-content select=\"[ds-nav-actions]\"></ng-content>\n</mat-toolbar>\n", styles: [":host{display:block}.ds-nav-header{height:56px;padding:0 12px;box-shadow:0 2px 4px #0003}.ds-nav-header__brand{font-size:18px;font-weight:700;letter-spacing:.04em;margin:0 24px 0 8px}.ds-nav-header__links{display:flex;gap:4px}.ds-nav-header__link--active{border-bottom:2px solid #fff;border-radius:0}.ds-nav-header__spacer{flex:1 1 auto}::ng-deep .ds-nav-header .mat-toolbar-row,::ng-deep .ds-nav-header.mat-toolbar-single-row{height:56px}::ng-deep .ds-nav-header .ds-nav-header__link .mat-button-wrapper{font-size:13px;font-weight:500;text-transform:uppercase;letter-spacing:.06em}::ng-deep .ds-nav-header .ds-nav-header__menu .mat-button-wrapper{display:flex;align-items:center;justify-content:center}\n"] }]
        }], propDecorators: { appName: [{
                type: Input
            }], links: [{
                type: Input
            }], navigate: [{
                type: Output
            }], menuToggle: [{
                type: Output
            }] } });

const COMPONENTS = [
    DsButtonComponent,
    DsCardComponent,
    DsFormFieldComponent,
    DsDataTableComponent,
    DsAlertComponent,
    DsNavHeaderComponent,
];
class DsComponentsModule {
}
DsComponentsModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
DsComponentsModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "14.3.0", ngImport: i0, type: DsComponentsModule, declarations: [DsButtonComponent,
        DsCardComponent,
        DsFormFieldComponent,
        DsDataTableComponent,
        DsAlertComponent,
        DsNavHeaderComponent], imports: [CommonModule,
        MatButtonModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatTableModule,
        MatIconModule,
        MatToolbarModule], exports: [DsButtonComponent,
        DsCardComponent,
        DsFormFieldComponent,
        DsDataTableComponent,
        DsAlertComponent,
        DsNavHeaderComponent] });
DsComponentsModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsComponentsModule, imports: [CommonModule,
        MatButtonModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatTableModule,
        MatIconModule,
        MatToolbarModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: COMPONENTS,
                    imports: [
                        CommonModule,
                        MatButtonModule,
                        MatCardModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatTableModule,
                        MatIconModule,
                        MatToolbarModule,
                    ],
                    exports: COMPONENTS,
                }]
        }] });

/*
 * Public API Surface of ds-components
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DsAlertComponent, DsButtonComponent, DsCardComponent, DsComponentsModule, DsDataTableComponent, DsFormFieldComponent, DsNavHeaderComponent };
//# sourceMappingURL=ds-components.mjs.map
