import * as i0 from "@angular/core";
import * as i1 from "./button/ds-button.component";
import * as i2 from "./card/ds-card.component";
import * as i3 from "./form-field/ds-form-field.component";
import * as i4 from "./data-table/ds-data-table.component";
import * as i5 from "./alert/ds-alert.component";
import * as i6 from "./nav-header/ds-nav-header.component";
import * as i7 from "@angular/common";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/card";
import * as i10 from "@angular/material/form-field";
import * as i11 from "@angular/material/input";
import * as i12 from "@angular/material/table";
import * as i13 from "@angular/material/icon";
import * as i14 from "@angular/material/toolbar";
export declare class DsComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DsComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DsComponentsModule, [typeof i1.DsButtonComponent, typeof i2.DsCardComponent, typeof i3.DsFormFieldComponent, typeof i4.DsDataTableComponent, typeof i5.DsAlertComponent, typeof i6.DsNavHeaderComponent], [typeof i7.CommonModule, typeof i8.MatButtonModule, typeof i9.MatCardModule, typeof i10.MatFormFieldModule, typeof i11.MatInputModule, typeof i12.MatTableModule, typeof i13.MatIconModule, typeof i14.MatToolbarModule], [typeof i1.DsButtonComponent, typeof i2.DsCardComponent, typeof i3.DsFormFieldComponent, typeof i4.DsDataTableComponent, typeof i5.DsAlertComponent, typeof i6.DsNavHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DsComponentsModule>;
}
