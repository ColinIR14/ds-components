import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class DsFormFieldComponent implements ControlValueAccessor {
    label: string;
    placeholder: string;
    hint: string;
    error: string;
    type: string;
    required: boolean;
    value: string;
    disabled: boolean;
    private onChange;
    private onTouched;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(event: Event): void;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsFormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsFormFieldComponent, "ds-form-field", never, { "label": "label"; "placeholder": "placeholder"; "hint": "hint"; "error": "error"; "type": "type"; "required": "required"; }, {}, never, never, false>;
}
