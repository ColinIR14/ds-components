import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class DsFormFieldComponent implements ControlValueAccessor {
    label: string;
    placeholder: string;
    hint: string;
    error: string;
    type: string;
    required: boolean;
    value: string;
    disabled: boolean;
    private onChange;
    private onTouched;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(event: Event): void;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsFormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsFormFieldComponent, "ds-form-field", never, { "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "type": { "alias": "type"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, never, false, never>;
}
