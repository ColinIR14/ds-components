import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type DsButtonVariant = 'primary' | 'secondary' | 'danger';
export declare class DsButtonComponent {
    variant: DsButtonVariant;
    disabled: boolean;
    type: 'button' | 'submit' | 'reset';
    clicked: EventEmitter<MouseEvent>;
    get color(): 'primary' | 'accent' | 'warn';
    onClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsButtonComponent, "ds-button", never, { "variant": { "alias": "variant"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, { "clicked": "clicked"; }, never, ["*"], false, never>;
}
