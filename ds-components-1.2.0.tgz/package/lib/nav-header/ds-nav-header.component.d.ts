import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface DsNavLink {
    label: string;
    route: string;
    active?: boolean;
}
export declare class DsNavHeaderComponent {
    appName: string;
    links: DsNavLink[];
    navigate: EventEmitter<DsNavLink>;
    menuToggle: EventEmitter<void>;
    onNavigate(link: DsNavLink, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsNavHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsNavHeaderComponent, "ds-nav-header", never, { "appName": "appName"; "links": "links"; }, { "navigate": "navigate"; "menuToggle": "menuToggle"; }, never, ["[ds-nav-actions]"], false>;
}
