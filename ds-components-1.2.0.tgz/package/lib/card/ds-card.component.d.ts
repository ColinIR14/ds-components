import * as i0 from "@angular/core";
export declare class DsCardComponent {
    title: string;
    subtitle: string;
    elevated: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsCardComponent, "ds-card", never, { "title": "title"; "subtitle": "subtitle"; "elevated": "elevated"; }, {}, never, ["*", "[ds-card-actions]"], false>;
}
