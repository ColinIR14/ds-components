import * as i0 from "@angular/core";
export declare class DsCardComponent {
    title: string;
    subtitle: string;
    elevated: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsCardComponent, "ds-card", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "elevated": { "alias": "elevated"; "required": false; }; }, {}, never, ["*", "[ds-card-actions]"], false, never>;
}
