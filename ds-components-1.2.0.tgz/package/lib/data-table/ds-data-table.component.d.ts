import * as i0 from "@angular/core";
export interface DsTableColumn {
    key: string;
    header: string;
    width?: string;
}
export declare class DsDataTableComponent {
    columns: DsTableColumn[];
    rows: Record<string, unknown>[];
    striped: boolean;
    get displayedColumns(): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<DsDataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsDataTableComponent, "ds-data-table", never, { "columns": { "alias": "columns"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "striped": { "alias": "striped"; "required": false; }; }, {}, never, never, false, never>;
}
