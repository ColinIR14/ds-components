import * as i0 from "@angular/core";
export interface DsTableColumn {
    key: string;
    header: string;
    width?: string;
}
export declare class DsDataTableComponent {
    columns: DsTableColumn[];
    rows: Record<string, unknown>[];
    striped: boolean;
    get displayedColumns(): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<DsDataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsDataTableComponent, "ds-data-table", never, { "columns": "columns"; "rows": "rows"; "striped": "striped"; }, {}, never, never, false>;
}
