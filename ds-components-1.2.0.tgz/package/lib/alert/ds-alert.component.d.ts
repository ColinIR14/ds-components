import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare type DsAlertSeverity = 'info' | 'success' | 'warning' | 'error';
export declare class DsAlertComponent {
    severity: DsAlertSeverity;
    title: string;
    dismissible: boolean;
    dismissed: EventEmitter<void>;
    visible: boolean;
    get icon(): string;
    dismiss(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsAlertComponent, "ds-alert", never, { "severity": "severity"; "title": "title"; "dismissible": "dismissible"; }, { "dismissed": "dismissed"; }, never, ["*"], false>;
}
